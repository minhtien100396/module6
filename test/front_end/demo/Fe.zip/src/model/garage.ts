export interface Garage {
  id?: number,
  name?: string,
  status?: number
}
